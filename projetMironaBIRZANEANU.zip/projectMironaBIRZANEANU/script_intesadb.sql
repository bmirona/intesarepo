-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 16, 2016 at 09:55 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `intesadb`
--

-- --------------------------------------------------------

--
-- Table structure for table `commitee`
--

CREATE TABLE IF NOT EXISTS `commitee` (
  `idCommitee` int(11) NOT NULL AUTO_INCREMENT,
  `nameCom` varchar(255) NOT NULL,
  `descriptionCom` text NOT NULL,
  `idCountry` int(11) NOT NULL,
  PRIMARY KEY (`idCommitee`),
  KEY `idCountry` (`idCountry`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `commitee`
--

INSERT INTO `commitee` (`idCommitee`, `nameCom`, `descriptionCom`, `idCountry`) VALUES
(2, 'Bucharest', 'beatiful cityyyy', 8),
(3, 'barcelone', 'lovely city', 10),
(4, 'valencia', 'what a wonderful city', 10);

-- --------------------------------------------------------

--
-- Table structure for table `country`
--

CREATE TABLE IF NOT EXISTS `country` (
  `idCountry` int(11) NOT NULL AUTO_INCREMENT,
  `nameC` varchar(255) NOT NULL,
  `descriptionC` text NOT NULL,
  PRIMARY KEY (`idCountry`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `country`
--

INSERT INTO `country` (`idCountry`, `nameC`, `descriptionC`) VALUES
(8, 'romania', 'In Romania we already have 2 committees '),
(10, 'Spain', 'Barcelone was the first commitee in Spain, but Valencia just joined us.');

--
-- Triggers `country`
--
DROP TRIGGER IF EXISTS `del_commitee_on_country`;
DELIMITER //
CREATE TRIGGER `del_commitee_on_country` AFTER DELETE ON `country`
 FOR EACH ROW BEGIN
	DELETE FROM commitee WHERE idCountry=OLD.idCountry ;
END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `doevent`
--

CREATE TABLE IF NOT EXISTS `doevent` (
  `idEvent` int(11) NOT NULL,
  `idCommitee` int(11) NOT NULL,
  KEY `idEvent` (`idEvent`,`idCommitee`),
  KEY `idCommitee` (`idCommitee`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE IF NOT EXISTS `event` (
  `idEvent` int(11) NOT NULL AUTO_INCREMENT,
  `nameEvent` varchar(255) NOT NULL,
  `descriptionEvent` text,
  PRIMARY KEY (`idEvent`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`idEvent`, `nameEvent`, `descriptionEvent`) VALUES
(1, 'ssa', 'soft skills academy'),
(3, 'io', 'intesa olympics');

--
-- Triggers `event`
--
DROP TRIGGER IF EXISTS `unique_name_event`;
DELIMITER //
CREATE TRIGGER `unique_name_event` BEFORE INSERT ON `event`
 FOR EACH ROW begin
	if(new.nameEvent IN (select event.nameEvent from event)) then
		SIGNAL SQLSTATE '45000' set MESSAGE_TEXT = "This event took place.Use the number of edition to insert it in the database";
	end if;
end
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `participation`
--

CREATE TABLE IF NOT EXISTS `participation` (
  `idEvent` int(11) NOT NULL,
  `idUser` int(11) NOT NULL,
  KEY `idEvent` (`idEvent`,`idUser`),
  KEY `idUser` (`idUser`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `utilisateur`
--

CREATE TABLE IF NOT EXISTS `utilisateur` (
  `idUser` int(11) NOT NULL AUTO_INCREMENT,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `pseudo` varchar(255) NOT NULL,
  `isAdmin` enum('member','admin') NOT NULL DEFAULT 'member',
  `commitee` varchar(255) NOT NULL,
  PRIMARY KEY (`idUser`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `utilisateur`
--

INSERT INTO `utilisateur` (`idUser`, `firstName`, `lastName`, `password`, `email`, `pseudo`, `isAdmin`, `commitee`) VALUES
(21, 'elena', 'liana', '405baa490599055246ffe9cc02fbf9da11c8a4ba', 'ele@yahoo', 'test', 'member', 'paris'),
(22, 'anne-marie', 'vichie', '743139240ff612253817440d98acb2ce7939fbb4', 'anne@gmail.com', 'admin', 'admin', 'Bucharest'),
(23, 'Mirona', 'Birzaneanu', '6467baa3b187373e3931422e2a8ef22f3e447d77', 'miro@gmail.com', 'miro', 'member', 'Montpellier');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `commitee`
--
ALTER TABLE `commitee`
  ADD CONSTRAINT `fk_commitee` FOREIGN KEY (`idCountry`) REFERENCES `country` (`idCountry`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `doevent`
--
ALTER TABLE `doevent`
  ADD CONSTRAINT `fk1_doEvent` FOREIGN KEY (`idEvent`) REFERENCES `event` (`idEvent`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk2_doEvent` FOREIGN KEY (`idCommitee`) REFERENCES `commitee` (`idCommitee`) ON DELETE CASCADE;

--
-- Constraints for table `participation`
--
ALTER TABLE `participation`
  ADD CONSTRAINT `fk2_participation` FOREIGN KEY (`idUser`) REFERENCES `utilisateur` (`idUser`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk1_participation` FOREIGN KEY (`idEvent`) REFERENCES `event` (`idEvent`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
