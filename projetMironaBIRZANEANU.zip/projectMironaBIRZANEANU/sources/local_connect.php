<?php

try{

  $bdd = new PDO('mysql:host=hostname;dbname=datab;charset=utf8', 'root', '');

}
catch (Exception $e)

{
        die('Erreur : ' . $e->getMessage());
}
