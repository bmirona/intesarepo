<!DOCTYPE html>
<html lang="en">
    <head>

        <title>Edit Page</title>
         <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
        <link href="../framework/css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">
        <link rel="stylesheet" type="text/css" href="../framework/css/DT_bootstrap.css">
        <link href="../framework/modal/css1/bootstrap1.css" rel="stylesheet" type="text/css" media="screen">



</head>
<script src="../framework/modal/js1/jquery1.js" type="text/javascript"></script>
<script src="../framework/modal/js1/bootstrap1.js" type="text/javascript"></script>



<script src="../framework/js/jquery.js" type="text/javascript"></script>
<script src="../framework/js/bootstrap.js" type="text/javascript"></script>

<script type="text/javascript" charset="utf-8" language="javascript" src="../framework/js/jquery.dataTables.js"></script>
<script type="text/javascript" charset="utf-8" language="javascript" src="../framework/js/DT_bootstrap.js"></script>
