<footer class="page-footer teal #cfd8dc blue-grey lighten-4">
  <div class="container">
    <div class="row">
      <div class="col l6 s12">
        <h5 class="black-text">Parteners</h5>



      </div>

    </div>
  </div>
  <div class="footer-copyright">
    <div class="container">
  <!--  Made by--> <a class="black-text " href="http://materializecss.com">Made by Mirona</a>
    </div>
  </div>
</footer>


<!--  Scripts-->
<script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
<script src="framework/js/materialize.js"></script>
<script src="framework/js/init.js"></script>
