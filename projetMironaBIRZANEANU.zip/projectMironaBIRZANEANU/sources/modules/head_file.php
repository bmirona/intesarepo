<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no"/>

<link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
 <!-- CSS  -->
 <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
 <link href="./framework/css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
 <link href="./framework/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
<title>International Engineering Students Association </title>
